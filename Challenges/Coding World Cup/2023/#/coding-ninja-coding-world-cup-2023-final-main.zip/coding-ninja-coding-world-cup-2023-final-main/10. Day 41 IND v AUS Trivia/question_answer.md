Problem Statement
-
On a full charge the MX Master 3S stays powered for

Options:

- Less than 50 days 
- Up to 10 days 
- Between 30-50 days 
- Up to 70 days 


Correct Answer:
-
Up to 70 days 
 