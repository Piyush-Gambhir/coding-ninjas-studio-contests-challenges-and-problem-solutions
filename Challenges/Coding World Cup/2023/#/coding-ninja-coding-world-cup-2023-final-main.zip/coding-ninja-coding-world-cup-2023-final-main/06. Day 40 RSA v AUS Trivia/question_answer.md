Problem Statement
-
In the 1996 Cricket World Cup semi-final between India and Sri Lanka, a legendary batsman played a notable innings and also took two wickets, but his efforts were in vain as his team faced defeat. Who was this batsman?

Options:

- Sachin Tendulkar 
- Md Azharuddin
- Sanath Jayasuriya 
- Aravinda De Silva


Correct Answer:
-
Sachin Tendulkar 
 